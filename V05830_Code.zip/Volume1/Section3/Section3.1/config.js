module.exports = {
  redis_host: '127.0.0.1',
  redis_port: 16379
}
