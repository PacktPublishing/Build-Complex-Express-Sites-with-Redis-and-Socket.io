module.exports = {
  redis_host: '127.0.0.1',
  redis_port: 16379,
  expire: 60 * 60 * 1000
}
